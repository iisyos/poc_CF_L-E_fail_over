"use strict";

exports.handler = (event) => {
  console.log("Hello World!");
  return "Hello World!";
};
